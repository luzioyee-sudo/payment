import 'dotenv/config';
import express from 'express';
import cookieParser from 'cookie-parser';
import crypto from 'node:crypto';
import fs from 'node:fs';
import Stripe from 'stripe';

const {
  PORT = 3000, APP_URL = `http://localhost:${PORT}`,
  ADMIN_PASSWORD, SESSION_SECRET,
  STRIPE_SECRET_KEY, STRIPE_PUBLISHABLE_KEY,
  PAYPAL_ENV = 'sandbox', PAYPAL_CLIENT_ID, PAYPAL_CLIENT_SECRET,
} = process.env;


const stripe = STRIPE_SECRET_KEY ? new Stripe(STRIPE_SECRET_KEY) : null;
const paypalOn = Boolean(PAYPAL_CLIENT_ID && PAYPAL_CLIENT_SECRET);
const PAYPAL_API = PAYPAL_ENV === 'live' ? 'https://api-m.paypal.com' : 'https://api-m.sandbox.paypal.com';

// ---- tiny JSON store (swap for a real database in production) ----
const DB_FILE = './data.json';
const load = () => (fs.existsSync(DB_FILE) ? JSON.parse(fs.readFileSync(DB_FILE, 'utf8')) : { stripeCustomerId: null, paypal: [] });
const save = (d) => fs.writeFileSync(DB_FILE, JSON.stringify(d, null, 2));

// ---- auth: signed, expiring cookie ----
const sign = (v) => crypto.createHmac('sha256', SESSION_SECRET || 'unused').update(v).digest('hex');
const makeToken = () => { const exp = String(Date.now() + 8 * 3600e3); return `${exp}.${sign(exp)}`; };
const validToken = (t = '') => {
  const [exp, sig] = t.split('.');
  if (!exp || !sig || Number(exp) < Date.now()) return false;
  const good = Buffer.from(sign(exp)); const got = Buffer.from(sig);
  return good.length === got.length && crypto.timingSafeEqual(good, got);
};
// No password for now. Anyone who can open this site can manage payment methods,
// so keep it on localhost or behind your own login before sharing it.
const requireAdmin = (_req, _res, next) => next();

const app = express();
app.use(express.json());
app.use(cookieParser());
app.use(express.static('public'));

const wrap = (fn) => (req, res) => fn(req, res).catch((e) => {
  console.error(e);
  res.status(500).json({ error: e.message || 'Something went wrong.' });
});

app.post('/api/login', (req, res) => {
  const a = Buffer.from(String(req.body.password ?? '')); const b = Buffer.from(ADMIN_PASSWORD);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return res.status(401).json({ error: 'Wrong password.' });
  res.cookie('session', makeToken(), { httpOnly: true, sameSite: 'lax', secure: APP_URL.startsWith('https'), maxAge: 8 * 3600e3 });
  res.json({ ok: true });
});
app.post('/api/logout', (_req, res) => { res.clearCookie('session'); res.json({ ok: true }); });
app.get('/api/session', (_req, res) => res.json({ signedIn: true }));

app.get('/api/config', requireAdmin, (_req, res) => res.json({
  stripe: stripe ? { publishableKey: STRIPE_PUBLISHABLE_KEY } : null,
  paypal: paypalOn ? { clientId: PAYPAL_CLIENT_ID, env: PAYPAL_ENV } : null,
}));

// ---- list every saved method (Stripe is read live from Stripe) ----
app.get('/api/methods', requireAdmin, wrap(async (_req, res) => {
  const db = load(); const methods = [];
  if (stripe && db.stripeCustomerId) {
    const pms = await stripe.paymentMethods.list({ customer: db.stripeCustomerId, limit: 50 });
    for (const pm of pms.data) {
      methods.push({
        provider: 'stripe', id: pm.id, type: pm.type,
        label: pm.card ? `${pm.card.brand} •••• ${pm.card.last4}` : pm.type,
        detail: pm.card ? `Expires ${String(pm.card.exp_month).padStart(2, '0')}/${pm.card.exp_year}` : '',
      });
    }
  }
  for (const p of db.paypal) methods.push({ provider: 'paypal', id: p.id, type: 'paypal', label: 'PayPal', detail: p.email || '' });
  res.json({ methods });
}));

// ---- Stripe: SetupIntent saves a method without charging ----
app.post('/api/stripe/setup-intent', requireAdmin, wrap(async (_req, res) => {
  if (!stripe) return res.status(400).json({ error: 'Stripe is not configured.' });
  const db = load();
  if (!db.stripeCustomerId) {
    const c = await stripe.customers.create({ description: 'Admin account' });
    db.stripeCustomerId = c.id; save(db);
  }
  const si = await stripe.setupIntents.create({
    customer: db.stripeCustomerId,
    automatic_payment_methods: { enabled: true },
    usage: 'off_session',
  });
  res.json({ clientSecret: si.client_secret });
}));

app.delete('/api/stripe/:id', requireAdmin, wrap(async (req, res) => {
  const db = load();
  const pm = await stripe.paymentMethods.retrieve(req.params.id);
  if (pm.customer !== db.stripeCustomerId) return res.status(403).json({ error: 'Not your payment method.' });
  await stripe.paymentMethods.detach(req.params.id);
  res.json({ ok: true });
}));

// ---- PayPal: Vault v3 (setup token -> approve -> payment token) ----
async function paypalFetch(path, opts = {}) {
  const basic = Buffer.from(`${PAYPAL_CLIENT_ID}:${PAYPAL_CLIENT_SECRET}`).toString('base64');
  const tokRes = await fetch(`${PAYPAL_API}/v1/oauth2/token`, {
    method: 'POST',
    headers: { Authorization: `Basic ${basic}`, 'Content-Type': 'application/x-www-form-urlencoded' },
    body: 'grant_type=client_credentials',
  });
  const tok = await tokRes.json();
  if (!tokRes.ok) throw new Error(tok.error_description || 'PayPal auth failed. Check your client ID and secret.');
  const r = await fetch(`${PAYPAL_API}${path}`, {
    ...opts,
    headers: { Authorization: `Bearer ${tok.access_token}`, 'Content-Type': 'application/json', 'PayPal-Request-Id': crypto.randomUUID(), ...(opts.headers || {}) },
  });
  const text = await r.text(); const data = text ? JSON.parse(text) : {};
  if (!r.ok) throw new Error(data.message || data.details?.[0]?.description || 'PayPal request failed.');
  return data;
}

app.post('/api/paypal/setup-token', requireAdmin, wrap(async (_req, res) => {
  if (!paypalOn) return res.status(400).json({ error: 'PayPal is not configured.' });
  const data = await paypalFetch('/v3/vault/setup-tokens', {
    method: 'POST',
    body: JSON.stringify({
      payment_source: { paypal: { usage_type: 'MERCHANT', experience_context: { return_url: `${APP_URL}/?paypal=ok`, cancel_url: `${APP_URL}/?paypal=cancel` } } },
    }),
  });
  res.json({ id: data.id });
}));

app.post('/api/paypal/payment-token', requireAdmin, wrap(async (req, res) => {
  const data = await paypalFetch('/v3/vault/payment-tokens', {
    method: 'POST',
    body: JSON.stringify({ payment_source: { token: { id: req.body.setupTokenId, type: 'SETUP_TOKEN' } } }),
  });
  const db = load();
  db.paypal.push({ id: data.id, customerId: data.customer?.id, email: data.payment_source?.paypal?.email_address || '' });
  save(db);
  res.json({ ok: true });
}));

app.delete('/api/paypal/:id', requireAdmin, wrap(async (req, res) => {
  const db = load();
  if (!db.paypal.some((p) => p.id === req.params.id)) return res.status(404).json({ error: 'Not found.' });
  await paypalFetch(`/v3/vault/payment-tokens/${encodeURIComponent(req.params.id)}`, { method: 'DELETE' });
  db.paypal = db.paypal.filter((p) => p.id !== req.params.id); save(db);
  res.json({ ok: true });
}));

app.listen(PORT, () => console.log(`Admin running at ${APP_URL}`));

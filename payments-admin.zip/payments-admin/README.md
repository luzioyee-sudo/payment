# Payments admin (Stripe + PayPal)

An admin page that saves real payment methods: cards through Stripe, PayPal accounts through PayPal Vault. Nothing is charged when a method is saved.

## Run it
1. `npm install`
2. `cp .env.example .env`, then fill it in (use test/sandbox keys first)
3. `npm start`, then open http://localhost:3000

Set only the providers you want; the page hides any that have no keys.

## Where to get keys
- Stripe: dashboard.stripe.com > Developers > API keys
- PayPal: developer.paypal.com > Apps & Credentials. Vaulting must be enabled on your PayPal business account (ask PayPal support if the setup-token call returns a permissions error).

## Test it
- Stripe test card: 4242 4242 4242 4242, any future date, any CVC
- PayPal: use a sandbox buyer account

## Going live
- Serve over HTTPS and set `APP_URL` to your https URL
- Swap `data.json` for a real database; scope records per user, not one shared account
- There is no password right now: add your own login before putting this on a public URL
- Use live keys and set `PAYPAL_ENV=live`
- Keep secret keys in the server environment only; never in `public/`
